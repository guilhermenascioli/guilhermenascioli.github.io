"""Notícias e relações com ativos no mesmo SQLite das cotações."""
import json
from pathlib import Path


def _save(db, per_asset, now_iso):
    counts = {}
    for ticker, entries in per_asset.items():
        for item, rel in entries:
            old = db.execute("SELECT id FROM news WHERE id=? OR hash=? ORDER BY id=? DESC LIMIT 1", (item.id,item.hash,item.id)).fetchone()
            news_id = old[0] if old else item.id
            if not old:
                db.execute("""INSERT INTO news(id,hash,title,url,source_id,source_name,published_at,collected_at,
                  last_seen_at,summary,content,author,categories_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (item.id,item.hash,item.title,item.url,item.source_id,item.source_name,item.published_at,
                   item.collected_at,now_iso,item.summary,item.content,item.author,json.dumps(item.categories,ensure_ascii=False)))
            elif news_id == item.id:
                db.execute("""UPDATE news SET title=?,url=?,source_id=?,source_name=?,published_at=?,last_seen_at=?,
                  summary=?,content=?,author=?,categories_json=? WHERE id=?""",
                  (item.title,item.url,item.source_id,item.source_name,item.published_at,now_iso,item.summary,item.content,
                   item.author,json.dumps(item.categories,ensure_ascii=False),news_id))
            else:
                db.execute("UPDATE news SET last_seen_at=? WHERE id=?", (now_iso,news_id))
            db.execute("""INSERT INTO news_assets VALUES(?,?,?,?) ON CONFLICT(news_id,ticker)
              DO UPDATE SET score=excluded.score,matched_json=excluded.matched_json""",
              (news_id,ticker,rel.score,json.dumps(rel.matched,ensure_ascii=False)))
        counts[ticker] = db.execute("SELECT COUNT(*) FROM news_assets WHERE ticker=?", (ticker,)).fetchone()[0]
    return counts


def save_news(db, per_asset, now_iso):
    with db:
        return _save(db, per_asset, now_iso)


def import_legacy(db, folder):
    """Importação idempotente; nunca modifica os arquivos de origem."""
    from .models import NewsItem
    from .filters import Relevance
    from ..market import utc_now
    per_asset, analyses = {}, []
    for ticker, in db.execute("SELECT ticker FROM assets WHERE active=1").fetchall():
        path = Path(folder) / f"{ticker}.json"
        if not path.exists():
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        entries = []
        for entry in payload.get("items", []):
            fields = {key:value for key,value in entry.items() if key in NewsItem.__dataclass_fields__}
            item = NewsItem(**fields)
            rel = entry.get("relevance", {})
            entries.append((item,Relevance(ticker,rel.get("score",0),rel.get("matched",[]))))
            if "analysis" in entry:
                analyses.append((json.dumps(entry["analysis"],ensure_ascii=False),item.id,item.hash))
        per_asset[ticker] = entries
    with db:
        counts = _save(db, per_asset, utc_now())
        for analysis,news_id,news_hash in analyses:
            db.execute("UPDATE news SET analysis_json=COALESCE(analysis_json,?) WHERE id=? OR hash=?", (analysis,news_id,news_hash))
    return counts
