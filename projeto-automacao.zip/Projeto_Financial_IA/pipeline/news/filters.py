"""Relação entre notícia e ativo (primeira versão baseada em regras).

Como funciona: cada ativo tem sinais FORTES (ticker e nome da empresa) e FRACOS
(palavras-chave do setor). Um sinal no título/categorias vale mais do que no corpo.
Palavras-chave sozinhas nunca bastam: é preciso ao menos um sinal forte.

Para trocar por um classificador melhor no futuro, basta criar uma classe com o
método `evaluate(item)` (ver RelevanceFilter) e usá-la no run_collect.py.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol

from .models import NewsItem, normalize_text

# names: expressões regulares. (?i:...) = ignora maiúsculas só naquele trecho.
# Cuidado com nomes ambíguos: "Vale" (verbo), "Itaú BBA" (analista, não o banco),
# "B3" (aparece em "negociadas na B3", sem ser notícia sobre a B3).
ASSET_KEYWORDS: dict[str, dict] = {
    "PETR4": {
        "company": "Petrobras",
        "tickers": ["PETR4", "PETR3"],
        "names": [r"(?i:\bpetrobras\b)"],
        "keywords": ["petróleo", "pré-sal", "Margem Equatorial", "Foz do Amazonas", "refino", "Brent", "combustíveis"],
    },
    "VALE3": {
        "company": "Vale",
        "tickers": ["VALE3"],
        "names": [r"\b(?:Vale|VALE)\b(?!\s+(?:a\s+pena|d[oa]s?)\b)"],
        "keywords": ["minério de ferro", "mineração", "Carajás", "pelotas"],
    },
    "ITUB4": {
        "company": "Itaú Unibanco",
        "tickers": ["ITUB4", "ITUB3"],
        "names": [r"(?i:\bita[uú] unibanco\b)", r"\bIta[uú]\b(?!\s*(?:BBA|Asset|Securities|Corretora|Cultural|sa)\b)"],
        "keywords": ["bancos", "setor bancário", "inadimplência", "crédito"],
    },
    "BBAS3": {
        "company": "Banco do Brasil",
        "tickers": ["BBAS3"],
        "names": [r"(?i:\bbanco do brasil\b)"],
        "keywords": ["crédito rural", "Plano Safra", "agronegócio", "bancos"],
    },
    "B3SA3": {
        "company": "B3",
        "tickers": ["B3SA3"],
        "names": [
            r"\bB3\s+S\.?A\.?",
            r"\bB3\s+(?:anuncia|divulga|informa|lan[cç]a|aprova|cria|prop[oõ]e|reajusta|registra|reporta|conclui)\b",
            r"(?i:\b(?:resultado|balan[cç]o|lucro|receita|dividendos?|a[cç][oõ]es)\s+d[ao]\s+B3\b)",
        ],
        "keywords": ["bolsa de valores", "Ibovespa", "IPO", "volume negociado"],
    },
}

MIN_SCORE = 2.0
TICKER_WEIGHT = 3.0
NAME_WEIGHT = 2.0
BODY_FACTOR = 0.75  # sinal só no corpo vale menos do que no título
KEYWORD_HEAD, KEYWORD_BODY, KEYWORD_CAP = 0.75, 0.4, 1.5
BODY_CHARS = 1500


@dataclass
class Relevance:
    ticker: str
    score: float
    matched: list[str]

    def to_dict(self) -> dict:
        return {"score": round(self.score, 2), "matched": self.matched}


class RelevanceFilter(Protocol):
    def evaluate(self, item: NewsItem) -> list[Relevance]: ...


class RuleBasedFilter:
    def __init__(self, config: dict[str, dict] = ASSET_KEYWORDS, min_score: float = MIN_SCORE) -> None:
        self.min_score = min_score
        self._assets = {
            ticker: {
                "tickers": [re.compile(rf"\b{t}\b", re.I) for t in cfg["tickers"]],
                "names": [re.compile(p) for p in cfg["names"]],
                "keywords": [(kw, f" {normalize_text(kw)} ") for kw in cfg["keywords"]],
            }
            for ticker, cfg in config.items()
        }

    @staticmethod
    def _zones(item: NewsItem) -> tuple[str, str]:
        head = " ".join([item.title, *item.categories])
        body = " ".join(filter(None, [item.summary, (item.content or "")[:BODY_CHARS]]))
        return head, body

    def evaluate(self, item: NewsItem) -> list[Relevance]:
        head, body = self._zones(item)
        head_norm, body_norm = f" {normalize_text(head)} ", f" {normalize_text(body)} "
        results: list[Relevance] = []
        for ticker, cfg in self._assets.items():
            score, matched = 0.0, []
            for kind, patterns, weight in (("ticker", cfg["tickers"], TICKER_WEIGHT), ("name", cfg["names"], NAME_WEIGHT)):
                best, label = 0.0, ""
                for p in patterns:
                    if p.search(head):
                        value = weight
                    elif p.search(body):
                        value = weight * BODY_FACTOR
                    else:
                        continue
                    if value > best:
                        best, label = value, f"{kind}:{p.pattern}"
                if best:
                    score += best
                    matched.append(label)
            strong = score > 0
            weak = 0.0
            for kw, kw_norm in cfg["keywords"]:
                if kw_norm in head_norm:
                    weak += KEYWORD_HEAD
                    matched.append(f"keyword:{kw}")
                elif kw_norm in body_norm:
                    weak += KEYWORD_BODY
                    matched.append(f"keyword:{kw}")
            if strong:
                score += min(weak, KEYWORD_CAP)
            if strong and score >= self.min_score:
                results.append(Relevance(ticker, score, matched))
        return results
