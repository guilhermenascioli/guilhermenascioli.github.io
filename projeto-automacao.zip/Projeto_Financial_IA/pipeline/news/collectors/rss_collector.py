"""Coletor RSS/Atom usando apenas a biblioteca padrão do Python (sem dependências)."""
from __future__ import annotations

import logging
import re
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from zoneinfo import ZoneInfo

from ..models import NewsItem
from ..sources import Source
from .base import CollectorError

log = logging.getLogger(__name__)

USER_AGENT = "AIFinancialMarketIntelligence/0.1 (portfolio project; +https://guilhermenascioli.github.io)"
MAX_BYTES = 5_000_000
SUMMARY_MAX_CHARS = 400
CONTENT_MAX_CHARS = 8_000

NS_DC = "{http://purl.org/dc/elements/1.1/}"
NS_CONTENT = "{http://purl.org/rss/1.0/modules/content/}"
NS_ATOM = "{http://www.w3.org/2005/Atom}"

# Bloco "Notícias relacionadas" que a Agência Brasil injeta no texto.
_RELATED_RE = re.compile(r"<h3>\s*Not[ií]cias relacionadas:?\s*</h3>\s*<ul>.*?</ul>", re.S | re.I)
_BLOCK_TAGS = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "blockquote", "ul", "ol"}


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self._skip += 1
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in {"script", "style"} and self._skip:
            self._skip -= 1
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def html_to_text(raw: str | None) -> str:
    if not raw:
        return ""
    parser = _TextExtractor()
    parser.feed(_RELATED_RE.sub("", raw))
    text = "".join(parser.parts).replace("\xa0", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s*\n\s*", "\n", text)
    return text.strip()


def truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0].rstrip(",;:.") + "…"


def parse_date(value: str | None, naive_tz: str = "UTC") -> str | None:
    """Converte qualquer formato comum de data do feed para ISO 8601 em UTC."""
    if not value or not value.strip():
        return None
    value = value.strip()
    dt: datetime | None = None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            dt = datetime.strptime(value, fmt)
            break
        except ValueError:
            continue
    if dt is None:
        try:
            dt = parsedate_to_datetime(value)  # formato RFC 822 (RSS)
        except (TypeError, ValueError):
            try:
                dt = datetime.fromisoformat(value.replace("Z", "+00:00"))  # Atom
            except ValueError:
                return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc if naive_tz == "UTC" else ZoneInfo(naive_tz))
    return dt.astimezone(timezone.utc).isoformat()


def _text(el: ET.Element | None) -> str:
    return (el.text or "").strip() if el is not None else ""


def _build_item(
    source: Source, collected_at: str, title: str, url: str, date: str, raw_html: str, author: str, categories: list[str]
) -> NewsItem | None:
    title = html_to_text(title)
    if not title or not url:
        return None
    full_text = html_to_text(raw_html)
    first_paragraph = full_text.split("\n", 1)[0] if full_text else ""
    return NewsItem(
        title=title,
        url=url,
        source_id=source.id,
        source_name=source.name,
        published_at=parse_date(date, source.naive_tz),
        collected_at=collected_at,
        summary=truncate(first_paragraph, SUMMARY_MAX_CHARS) or None,
        content=truncate(full_text, CONTENT_MAX_CHARS) if (source.store_content and full_text) else None,
        author=author or None,
        categories=categories,
    )


def parse_feed(xml_bytes: bytes, source: Source, collected_at: str) -> list[NewsItem]:
    """Função pura (sem rede): transforma o XML do feed em NewsItem normalizados."""
    head = xml_bytes[:4096].lower()
    if b"<!doctype" in head or b"<!entity" in head:  # evita ataques de expansão de entidades
        raise CollectorError("XML com DOCTYPE/ENTITY rejeitado por segurança")
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise CollectorError(f"XML inválido: {exc}") from exc

    items: list[NewsItem] = []
    for node in root.iter("item"):  # RSS 2.0
        raw = _text(node.find(f"{NS_CONTENT}encoded")) or _text(node.find("description"))
        author = _text(node.find(f"{NS_DC}creator")) or _text(node.find("author"))
        cats = [c.text.strip() for c in node.findall("category") if c.text and c.text.strip()]
        item = _build_item(
            source, collected_at, _text(node.find("title")), _text(node.find("link")),
            _text(node.find("pubDate")), raw, author, cats,
        )
        if item:
            items.append(item)
    for node in root.iter(f"{NS_ATOM}entry"):  # Atom
        link = next((l.get("href", "") for l in node.findall(f"{NS_ATOM}link") if l.get("rel", "alternate") == "alternate"), "")
        raw = _text(node.find(f"{NS_ATOM}content")) or _text(node.find(f"{NS_ATOM}summary"))
        cats = [c.get("term", "").strip() for c in node.findall(f"{NS_ATOM}category") if c.get("term")]
        item = _build_item(
            source, collected_at, _text(node.find(f"{NS_ATOM}title")), link,
            _text(node.find(f"{NS_ATOM}published")) or _text(node.find(f"{NS_ATOM}updated")),
            raw, _text(node.find(f"{NS_ATOM}author/{NS_ATOM}name")), cats,
        )
        if item:
            items.append(item)
    return items


class RSSCollector:
    def __init__(self, timeout: int = 20, retries: int = 2) -> None:
        self.timeout = timeout
        self.retries = retries

    def fetch_xml(self, url: str) -> bytes:
        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            try:
                req = urllib.request.Request(
                    url, headers={"User-Agent": USER_AGENT, "Accept": "application/rss+xml, application/xml;q=0.9, */*;q=0.8"}
                )
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    data = resp.read(MAX_BYTES + 1)
                if len(data) > MAX_BYTES:
                    raise CollectorError("feed maior que o limite permitido")
                return data
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = exc
                log.warning("tentativa %d falhou para %s: %s", attempt + 1, url, exc)
                if attempt < self.retries:
                    time.sleep(1.5 * (attempt + 1))
        raise CollectorError(f"falha ao baixar {url}: {last_error}")

    def collect(self, source: Source, collected_at: str) -> list[NewsItem]:
        return parse_feed(self.fetch_xml(source.feed_url), source, collected_at)
