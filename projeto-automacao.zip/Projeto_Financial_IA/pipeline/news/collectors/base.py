from __future__ import annotations

from typing import Protocol

from ..models import NewsItem
from ..sources import Source


class CollectorError(Exception):
    """Falha ao coletar uma fonte (rede, XML inválido etc.)."""


class Collector(Protocol):
    def collect(self, source: Source, collected_at: str) -> list[NewsItem]: ...
