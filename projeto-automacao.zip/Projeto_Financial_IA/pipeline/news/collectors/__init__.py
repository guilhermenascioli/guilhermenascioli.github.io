"""Registro de coletores. Para um novo tipo de fonte (ex.: API), crie o coletor e registre aqui."""
from .base import Collector, CollectorError
from .rss_collector import RSSCollector

COLLECTORS: dict[str, type] = {"rss": RSSCollector}

__all__ = ["COLLECTORS", "Collector", "CollectorError", "RSSCollector"]
