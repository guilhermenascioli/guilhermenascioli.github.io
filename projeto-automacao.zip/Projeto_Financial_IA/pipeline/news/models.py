"""Formato único (normalizado) de notícia usado em todo o pipeline."""
from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def canonical_url(url: str) -> str:
    """Remove parâmetros de rastreio (utm_*, fbclid...) e normaliza a URL."""
    parts = urlsplit(url.strip())
    query = [
        (k, v)
        for k, v in parse_qsl(parts.query, keep_blank_values=True)
        if not k.lower().startswith("utm_") and k.lower() not in {"fbclid", "gclid"}
    ]
    return urlunsplit(
        (parts.scheme.lower(), parts.netloc.lower(), parts.path.rstrip("/") or "/", urlencode(query), "")
    )


def normalize_text(text: str) -> str:
    """minúsculas, sem acento e sem pontuação (para hash e comparações)."""
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", " ", ascii_text.lower()).strip()


def short_hash(text: str, size: int = 16) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:size]


@dataclass
class NewsItem:
    title: str
    url: str
    source_id: str
    source_name: str
    published_at: str | None  # ISO 8601 em UTC
    collected_at: str  # ISO 8601 em UTC
    summary: str | None = None
    content: str | None = None
    author: str | None = None
    categories: list[str] = field(default_factory=list)
    id: str = ""  # identificador único (hash da URL canônica)
    hash: str = ""  # hash do título normalizado (evita duplicatas com URLs diferentes)

    def __post_init__(self) -> None:
        self.url = canonical_url(self.url)
        if not self.id:
            self.id = short_hash(self.url)
        if not self.hash:
            self.hash = short_hash(normalize_text(self.title))

    def to_dict(self) -> dict:
        return asdict(self)
