"""Fontes de notícias. Para adicionar uma fonte nova, basta incluir uma linha em SOURCES.

Só entram aqui feeds publicados oficialmente pelo próprio site.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Source:
    id: str
    name: str
    feed_url: str
    kind: str = "rss"  # tipo de coletor (ver collectors/__init__.py)
    # Fuso usado quando o feed traz data SEM fuso (ex.: "2026-09-23 11:30:34").
    # O Investing.com não informa o fuso: confirme e ajuste se necessário.
    naive_tz: str = "UTC"
    # Guardar o texto completo no banco? Só ative se a licença permitir.
    store_content: bool = False
    enabled: bool = True


SOURCES: list[Source] = [
    # Investing.com Brasil — lista oficial: https://br.investing.com/webmaster-tools/rss
    # O feed traz só título, data, autor e link (sem resumo).
    Source("investing-acoes", "Investing.com Brasil", "https://br.investing.com/rss/news_25.rss"),
    # Listados na página oficial, mas ainda não testados um a um.
    Source("investing-empresas", "Investing.com Brasil", "https://br.investing.com/rss/news_356.rss"),
    Source("investing-commodities", "Investing.com Brasil", "https://br.investing.com/rss/news_11.rss"),
    Source("investing-economia", "Investing.com Brasil", "https://br.investing.com/rss/news_14.rss"),
    # Agência Brasil — traz texto completo e tags. Confirme a licença (CC-BY) no site
    # antes de manter store_content=True em um repositório público.
    Source(
        "agencia-brasil-economia",
        "Agência Brasil",
        "https://agenciabrasil.ebc.com.br/rss/economia/feed.xml",
        store_content=True,
    ),
]
