"""Coleta -> normalização -> deduplicação -> relevância por ativo -> SQLite.

Uso (na raiz do repositório):
    python -m pipeline.run_collect              # coleta e grava em data/carteira.sqlite3
    python -m pipeline.run_collect --dry-run    # só mostra o que encontraria
"""
from __future__ import annotations

import argparse
import logging
import sys
import sqlite3
from urllib.parse import urlencode
from datetime import datetime, timezone

from .news.collectors import COLLECTORS, CollectorError
from .news.filters import ASSET_KEYWORDS, RuleBasedFilter
from .news.models import NewsItem
from .news.sources import SOURCES, Source
from .news.collectors.rss_collector import RSSCollector
from .news.sqlite_storage import save_news
from .market import connect, sync_assets
from .portfolio import DEFAULT_CONFIG, DEFAULT_DB, load_portfolio

log = logging.getLogger("pipeline")


def collect_all(sources: list[Source], collected_at: str, timeout=20, retries=2) -> tuple[list[NewsItem], int, int]:
    """Retorna (notícias únicas, fontes com sucesso, fontes com falha)."""
    by_id: dict[str, NewsItem] = {}
    seen_hashes: set[str] = set()
    ok = failed = 0
    for source in (s for s in sources if s.enabled):
        collector = COLLECTORS[source.kind](timeout=timeout, retries=retries)
        try:
            items = collector.collect(source, collected_at)
        except CollectorError as exc:
            failed += 1
            log.error("fonte %s falhou: %s", source.id, exc)
            continue
        ok += 1
        log.info("fonte %s: %d notícias", source.id, len(items))
        for item in items:
            if item.id in by_id or item.hash in seen_hashes:
                continue
            by_id[item.id] = item
            seen_hashes.add(item.hash)
    return list(by_id.values()), ok, failed


def find_latest_fallback(ticker, company, scorer, collected_at, timeout, retries):
    query = urlencode({"q": f'"{company}" ({ticker})',
                       "hl": "pt-BR", "gl": "BR", "ceid": "BR:pt-419"})
    source = Source(f"google-news-{ticker}", "Google News (busca por empresa)",
                    "https://news.google.com/rss/search?" + query)
    try:
        items = RSSCollector(timeout=timeout, retries=retries).collect(source, collected_at)
    except CollectorError as exc:
        log.warning("%s: busca adicional falhou: %s", ticker, exc)
        return []
    matches = [(item, rel) for item in items for rel in scorer.evaluate(item)
               if rel.ticker == ticker and item.published_at]
    matches.sort(key=lambda entry: datetime.fromisoformat(entry[0].published_at), reverse=True)
    if matches:
        item = matches[0][0]
        log.info("%s: última relevante encontrada na busca adicional: %s | %s | %s",
                 ticker, item.title, item.published_at, item.url)
    return matches[:1]


def show_saved_fallback(db, tickers):
    for ticker in tickers:
        row = db.execute("""SELECT n.title,n.url,n.published_at FROM news n
            JOIN news_assets a ON a.news_id=n.id WHERE a.ticker=? AND a.score>=2
            ORDER BY julianday(n.published_at) DESC,julianday(n.collected_at) DESC,n.id DESC
            LIMIT 1""", (ticker,)).fetchone()
        if row:
            log.info("%s: usando última relevante salva: %s | %s | %s", ticker, *row)
        else:
            log.warning("%s: nenhuma notícia relevante encontrada na busca ou no banco", ticker)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", default=str(DEFAULT_DB), help="banco SQLite compartilhado")
    parser.add_argument("--config", default=str(DEFAULT_CONFIG), help="arquivo da carteira")
    parser.add_argument("--timeout", type=int, default=20)
    parser.add_argument("--retries", type=int, choices=(0, 1, 2), default=2)
    parser.add_argument("--dry-run", action="store_true", help="não grava arquivos")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(levelname)s %(message)s")

    if args.timeout <= 0:
        parser.error("timeout deve ser positivo")
    try:
        portfolio = load_portfolio(args.config)
    except (OSError, ValueError) as exc:
        log.error("Configuração inválida: %s", exc)
        return 1
    tickers = [asset["ticker"] for asset in portfolio["assets"]]
    unknown = set(tickers) - ASSET_KEYWORDS.keys()
    if unknown:
        log.error("ativos sem regras de notícias: %s", ", ".join(sorted(unknown)))
        return 1
    asset_rules = {ticker: ASSET_KEYWORDS[ticker] for ticker in tickers}
    now_iso = datetime.now(timezone.utc).isoformat(timespec="seconds")
    items, ok, failed = collect_all(SOURCES, now_iso, args.timeout, args.retries)

    scorer = RuleBasedFilter(config=asset_rules)
    per_asset = {ticker: [] for ticker in tickers}
    for item in items:
        for rel in scorer.evaluate(item):
            per_asset[rel.ticker].append((item, rel))
    fallback_ok = 0
    for asset in portfolio["assets"]:
        ticker = asset["ticker"]
        if not per_asset[ticker]:
            per_asset[ticker] = find_latest_fallback(ticker, asset["company"], scorer,
                now_iso, args.timeout, args.retries)
            fallback_ok += bool(per_asset[ticker])
    missing = [ticker for ticker, entries in per_asset.items() if not entries]
    for ticker, found in per_asset.items():
        log.info("%s: %d notícias relevantes encontradas (feeds e busca adicional)", ticker, len(found))
        for item, rel in found[:3]:
            log.debug("  [%.2f] %s", rel.score, item.title)

    if args.dry_run:
        log.info("dry-run: nada foi gravado (%d notícias únicas, %d fontes ok, %d com falha)", len(items), ok, failed)
        return 0
    db = None
    try:
        db = connect(args.db)
        sync_assets(db, portfolio)
        show_saved_fallback(db, missing)
        counts = save_news(db, per_asset, now_iso)
        with db:
            db.execute("INSERT INTO news_runs(collected_at,status,sources_ok,sources_failed,unique_items) VALUES(?,?,?,?,?)",
                       (now_iso,"failed" if not ok and not fallback_ok else "partial" if failed else "ok",ok,failed,len(items)))
        log.info("gravado em %s: %s", args.db, counts)
    except (OSError, ValueError, sqlite3.Error) as exc:
        log.error("Não foi possível gravar notícias: %s", exc)
        return 1
    finally:
        if db is not None:
            db.close()
    return 1 if not ok and not fallback_ok else 2 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
