"""Coleta mercado para a carteira e grava em data/carteira.sqlite3."""
import argparse
import logging
import os
import sqlite3
from .market import BrapiClient, MarketError, connect, save_failure, save_success, sync_assets, utc_now
from .portfolio import DEFAULT_CONFIG, DEFAULT_DB, load_portfolio

log = logging.getLogger("market")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--db", default=str(DEFAULT_DB))
    parser.add_argument("--init-only", action="store_true", help="cria o banco e cadastra a carteira, sem rede")
    parser.add_argument("--quotes-only", action="store_true", help="não consulta o histórico diário")
    parser.add_argument("--range", choices=("1mo", "3mo"), default="3mo")
    parser.add_argument("--timeout", type=int, default=15)
    parser.add_argument("--retries", type=int, choices=(0, 1, 2), default=2)
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    if args.timeout <= 0:
        parser.error("timeout deve ser positivo")
    try:
        config = load_portfolio(args.config)
        db = connect(args.db)
        try:
            sync_assets(db, config)
            if args.init_only:
                log.info("Banco criado com %d ativos em %s", len(config["assets"]), args.db)
                return 0
            with db:
                run_id = db.execute("INSERT INTO collection_runs(started_at,status) VALUES(?,?)", (utc_now(), "running")).lastrowid
            client = BrapiClient(os.environ.get("BRAPI_TOKEN", ""), args.timeout, args.retries)
            ok = failed = 0
            try:
                for asset in config["assets"]:
                    ticker = asset["ticker"]
                    for endpoint in (("quote",) if args.quotes_only else ("quote", "historical")):
                        try:
                            if not client.token and ticker not in {"PETR4", "VALE3", "MGLU3", "ITUB4"}:
                                raise MarketError("Defina BRAPI_TOKEN: este ativo não está no sandbox sem token.")
                            params = {"range": args.range, "interval": "1d"} if endpoint == "historical" else {}
                            payload, data = client.fetch(endpoint, ticker, **params)
                            count = save_success(db, run_id, ticker, endpoint, payload, data)
                            ok += 1
                            log.info("%s %s: salvo%s", ticker, endpoint, f" ({count} pontos)" if endpoint == "historical" else "")
                        except MarketError as exc:
                            failed += 1
                            save_failure(db, run_id, ticker, endpoint, str(exc))
                            log.warning("%s %s: %s", ticker, endpoint, exc)
                status = "ok" if failed == 0 else "partial" if ok else "failed"
            except BaseException:
                with db:
                    db.execute("UPDATE collection_runs SET finished_at=?,status='interrupted' WHERE id=?", (utc_now(), run_id))
                raise
            with db:
                db.execute("UPDATE collection_runs SET finished_at=?,status=? WHERE id=?", (utc_now(), status, run_id))
            log.info("Banco: %s | consultas salvas: %d | falhas: %d", args.db, ok, failed)
            return 0 if failed == 0 else 2 if ok else 1
        finally:
            db.close()
    except (OSError, ValueError, sqlite3.Error) as exc:
        log.error("Não foi possível concluir: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
