"""Encrypted database persistence for GitHub Actions; no plaintext publication."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import urllib.request
import urllib.error
import zipfile
from cryptography.fernet import Fernet
from .portfolio import DEFAULT_DB, ROOT


def cipher():
    key = os.environ["STATE_KEY"]
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(key.encode()).digest()))


def restore():
    token = os.environ["GH_TOKEN"]
    repo = os.environ["GITHUB_REPOSITORY"]
    req = urllib.request.Request(f"https://api.github.com/repos/{repo}/actions/artifacts?name=portfolio-state&per_page=100", headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=30) as response:
        artifacts = json.load(response)["artifacts"]
    available = [a for a in artifacts if not a["expired"]]
    if available:
        latest = max(available, key=lambda a: a["id"])
        req = urllib.request.Request(latest["archive_download_url"], headers={"Authorization": f"Bearer {token}"})
        # Obtain redirect ourselves so the GitHub token is not forwarded to storage.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args): return None
        try:
            urllib.request.build_opener(NoRedirect).open(req, timeout=30)
        except urllib.error.HTTPError as exc:
            if exc.code != 302: raise
            location = exc.headers["Location"]
        with urllib.request.urlopen(location, timeout=60) as response:
            archive = response.read()
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            encrypted = z.read("state.enc")
    else:
        encrypted = (ROOT / "cloud" / "seed.enc").read_bytes()
    raw = cipher().decrypt(encrypted)
    DEFAULT_DB.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_DB.write_bytes(raw)
    with sqlite3.connect(DEFAULT_DB) as db:
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise RuntimeError("Banco restaurado inválido")
    print("Banco restaurado com sucesso")


def save():
    target = ROOT / "cloud" / "state.enc"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(cipher().encrypt(DEFAULT_DB.read_bytes()))
    print("Banco criptografado para a próxima execução")


if __name__ == "__main__":
    import sys
    {"restore": restore, "save": save}[sys.argv[1]]()
