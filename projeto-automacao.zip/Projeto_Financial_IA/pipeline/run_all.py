"""Atualiza mercado e notícias usando um único banco."""
import argparse
from .portfolio import DEFAULT_DB, DEFAULT_CONFIG
from .run_market import main as market_main
from .run_collect import main as news_main
from .analysis import main as analysis_main
from .dashboard import main as dashboard_main


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default=str(DEFAULT_DB))
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--init-only", action="store_true")
    parser.add_argument("--timeout", type=int, default=20)
    parser.add_argument("--retries", type=int, choices=(0, 1, 2), default=2)
    parser.add_argument("--only", choices=("market","news","analysis","export","all"), default="all")
    parser.add_argument("--skip-ai", action="store_true")
    args = parser.parse_args(argv)
    if args.timeout <= 0:
        parser.error("timeout deve ser positivo")
    shared = ["--db",args.db,"--config",args.config,
              "--timeout",str(args.timeout),"--retries",str(args.retries)]
    if args.init_only:
        return market_main([*shared,"--init-only"])
    results = []
    if args.only in ("market","all"):
        results.append(market_main(shared))
    if args.only in ("news","all"):
        results.append(news_main(shared))
    if args.only in ("analysis", "all") and not args.skip_ai:
        results.append(analysis_main(["--db", args.db]))
    results.append(dashboard_main(["--db", args.db]))
    return 0 if all(r == 0 for r in results) else 2 if any(r in (0, 2) for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
