"""Cliente brapi v2 e armazenamento SQLite, sem pacotes externos."""
import json
import math
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


class MarketError(Exception):
    pass


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def number(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return value
    return None


def iso_time(value):
    try:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return datetime.fromtimestamp(value, timezone.utc).isoformat()
        if isinstance(value, str):
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is not None:
                return dt.astimezone(timezone.utc).isoformat()
    except (ValueError, OverflowError, OSError):
        pass
    return None


class BrapiClient:
    def __init__(self, token="", timeout=15, retries=2):
        self.token = token.strip()
        self.timeout = timeout
        self.retries = retries

    def fetch(self, endpoint, ticker, **params):
        query = urllib.parse.urlencode({"symbols": ticker, **params})
        url = f"https://brapi.dev/api/v2/stocks/{endpoint}?{query}"
        headers = {"Accept": "application/json", "User-Agent": "PersonalPortfolio/1.0"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        for attempt in range(self.retries + 1):
            try:
                request = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    raw = response.read(5_000_001)
                if len(raw) > 5_000_000:
                    raise MarketError("Resposta maior que 5 MB.")
                payload = json.loads(raw)
                if not isinstance(payload, dict) or payload.get("error"):
                    raise MarketError("A API retornou erro ou formato inesperado.")
                results = payload.get("results")
                if not isinstance(results, list):
                    raise MarketError("Resposta sem lista de resultados.")
                for result in results:
                    if not isinstance(result, dict):
                        continue
                    if result.get("requestedSymbol", result.get("symbol")) == ticker:
                        if result.get("changed") or result.get("symbol") != ticker:
                            raise MarketError("Ticker mudou; revise a configuração da carteira.")
                        data = result.get("data")
                        if not isinstance(data, dict):
                            raise MarketError("Resultado sem objeto data da API v2.")
                        if endpoint == "quote" and (number(data.get("regularMarketPrice")) is None or data["regularMarketPrice"] <= 0):
                            raise MarketError("Cotação ausente ou inválida.")
                        if endpoint == "historical" and (not isinstance(data.get("historicalDataPrice"), list) or not data["historicalDataPrice"]):
                            raise MarketError("Histórico ausente ou vazio.")
                        return payload, data
                raise MarketError("Ativo não encontrado na resposta.")
            except urllib.error.HTTPError as exc:
                if exc.code not in (429, 500, 502, 503, 504) or attempt == self.retries:
                    hints = {401: "Token ausente ou inválido.", 403: "Recurso indisponível no plano ou sem autorização.", 404: "Ativo ou endpoint não encontrado.", 400: "Parâmetros ou histórico não permitido pelo plano.", 429: "Limite de consultas atingido."}
                    raise MarketError(f"HTTP {exc.code}: {hints.get(exc.code, 'Erro do serviço brapi.')}") from None
            except (urllib.error.URLError, TimeoutError, OSError):
                if attempt == self.retries:
                    raise MarketError("Não foi possível acessar a brapi: rede, timeout ou TLS.") from None
            except (ValueError, UnicodeError):
                raise MarketError("Resposta JSON inválida.") from None
            time.sleep(1.5 * (attempt + 1))


SCHEMA = """
CREATE TABLE IF NOT EXISTS assets (
 ticker TEXT PRIMARY KEY, company TEXT NOT NULL, quantity REAL NOT NULL,
 average_price REAL NOT NULL, fictitious INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS collection_runs (
 id INTEGER PRIMARY KEY, started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
 id INTEGER PRIMARY KEY, run_id INTEGER NOT NULL REFERENCES collection_runs(id),
 ticker TEXT NOT NULL REFERENCES assets(ticker), endpoint TEXT NOT NULL,
 fetched_at TEXT NOT NULL, status TEXT NOT NULL, error TEXT, payload_json TEXT
);
CREATE TABLE IF NOT EXISTS quote_snapshots (
 request_id INTEGER PRIMARY KEY REFERENCES requests(id), ticker TEXT NOT NULL REFERENCES assets(ticker),
 fetched_at TEXT NOT NULL, market_time TEXT, currency TEXT, price REAL NOT NULL,
 change REAL, change_percent REAL, open REAL, high REAL, low REAL,
 previous_close REAL, volume REAL, market_cap REAL, week52_low REAL, week52_high REAL
);
CREATE INDEX IF NOT EXISTS quotes_by_asset ON quote_snapshots(ticker, request_id DESC);
CREATE TABLE IF NOT EXISTS daily_prices (
 ticker TEXT NOT NULL REFERENCES assets(ticker), market_time TEXT NOT NULL,
 open REAL, high REAL, low REAL, close REAL NOT NULL, adjusted_close REAL, volume REAL,
 fetched_at TEXT NOT NULL, request_id INTEGER NOT NULL REFERENCES requests(id),
 PRIMARY KEY(ticker, market_time)
);
CREATE TABLE IF NOT EXISTS news (
 id TEXT PRIMARY KEY, hash TEXT NOT NULL UNIQUE, title TEXT NOT NULL, url TEXT NOT NULL,
 source_id TEXT NOT NULL, source_name TEXT NOT NULL, published_at TEXT,
 collected_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, summary TEXT, content TEXT,
 author TEXT, categories_json TEXT NOT NULL, analysis_json TEXT
);
CREATE TABLE IF NOT EXISTS news_assets (
 news_id TEXT NOT NULL REFERENCES news(id), ticker TEXT NOT NULL REFERENCES assets(ticker),
 score REAL NOT NULL, matched_json TEXT NOT NULL, PRIMARY KEY(news_id,ticker)
);
CREATE TABLE IF NOT EXISTS news_runs (
 id INTEGER PRIMARY KEY, collected_at TEXT NOT NULL, status TEXT NOT NULL,
 sources_ok INTEGER NOT NULL, sources_failed INTEGER NOT NULL, unique_items INTEGER NOT NULL
);
CREATE VIEW IF NOT EXISTS latest_quotes AS
 SELECT q.* FROM quote_snapshots q WHERE q.request_id=(
 SELECT MAX(q2.request_id) FROM quote_snapshots q2 WHERE q2.ticker=q.ticker);
CREATE VIEW IF NOT EXISTS portfolio_summary AS
 SELECT a.ticker, a.company, a.quantity, a.average_price, a.fictitious,
 q.price, q.currency, q.market_time, q.fetched_at,
 a.quantity*a.average_price AS invested_value,
 CASE WHEN q.currency='BRL' THEN a.quantity*q.price END AS market_value,
 CASE WHEN q.currency='BRL' THEN a.quantity*(q.price-a.average_price) END AS unrealized_result,
 CASE WHEN q.currency='BRL' THEN 100*(q.price-a.average_price)/NULLIF(a.average_price,0) END AS return_percent
 FROM assets a LEFT JOIN latest_quotes q ON q.ticker=a.ticker WHERE a.active=1;
"""


def connect(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path, timeout=20)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA)
    return db


def sync_assets(db, config):
    with db:
        db.execute("UPDATE assets SET active=0")
        db.executemany("""INSERT INTO assets(ticker,company,quantity,average_price,fictitious,active)
          VALUES(?,?,?,?,?,1) ON CONFLICT(ticker) DO UPDATE SET
          company=excluded.company,quantity=excluded.quantity,average_price=excluded.average_price,
          fictitious=excluded.fictitious,active=1""",
          [(a["ticker"], a["company"], a["quantity"], a["average_price"], int(config["fictitious"])) for a in config["assets"]])


def save_failure(db, run_id, ticker, endpoint, message):
    with db:
        db.execute("INSERT INTO requests(run_id,ticker,endpoint,fetched_at,status,error) VALUES(?,?,?,?,?,?)",
                   (run_id, ticker, endpoint, utc_now(), "failed", message))


def save_success(db, run_id, ticker, endpoint, payload, data):
    fetched_at = utc_now()
    # Validate all historical points before writing, so a bad response cannot partially overwrite the series.
    points = []
    if endpoint == "historical":
        for point in data["historicalDataPrice"]:
            if not isinstance(point, dict):
                raise MarketError("Ponto de histórico inválido.")
            timestamp = iso_time(point.get("date"))
            close = number(point.get("close"))
            if timestamp is None or close is None or close <= 0:
                raise MarketError("Histórico com data ou fechamento inválido.")
            points.append((ticker, timestamp, *[number(point.get(k)) for k in ("open", "high", "low")], close,
                           number(point.get("adjustedClose")), number(point.get("volume")), fetched_at))
    with db:
        request_id = db.execute("INSERT INTO requests(run_id,ticker,endpoint,fetched_at,status,payload_json) VALUES(?,?,?,?,?,?)",
                    (run_id, ticker, endpoint, fetched_at, "ok", json.dumps(payload, ensure_ascii=False, allow_nan=False))).lastrowid
        if endpoint == "quote":
            fields = ("regularMarketPrice", "regularMarketChange", "regularMarketChangePercent", "regularMarketOpen",
                      "regularMarketDayHigh", "regularMarketDayLow", "regularMarketPreviousClose", "regularMarketVolume",
                      "marketCap", "fiftyTwoWeekLow", "fiftyTwoWeekHigh")
            values = (request_id, ticker, fetched_at, iso_time(data.get("regularMarketTime")), data.get("currency"),
                      *[number(data.get(k)) for k in fields])
            db.execute("INSERT INTO quote_snapshots VALUES(" + ",".join("?" for _ in values) + ")", values)
        else:
            db.executemany("""INSERT INTO daily_prices VALUES(?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(ticker,market_time) DO UPDATE SET open=excluded.open,high=excluded.high,
              low=excluded.low,close=excluded.close,adjusted_close=excluded.adjusted_close,
              volume=excluded.volume,fetched_at=excluded.fetched_at,request_id=excluded.request_id""",
              [(*p, request_id) for p in points])
    return len(points)
