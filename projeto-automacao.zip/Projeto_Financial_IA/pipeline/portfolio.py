"""Configuração compartilhada pela coleta de notícias e de mercado."""
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = ROOT / "config" / "carteira.json"
DEFAULT_DB = ROOT / "data" / "carteira.sqlite3"


def load_portfolio(path=DEFAULT_CONFIG):
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    assets = config.get("assets")
    if not isinstance(assets, list) or not assets:
        raise ValueError("A carteira precisa conter uma lista não vazia de ativos.")
    seen = set()
    for asset in assets:
        ticker = asset.get("ticker", "")
        if not re.fullmatch(r"[A-Z]{4}[0-9]{1,2}", ticker) or ticker in seen:
            raise ValueError("Ticker inválido ou repetido na carteira.")
        seen.add(ticker)
        if not isinstance(asset.get("company"), str) or not asset["company"].strip():
            raise ValueError("Nome da empresa obrigatório.")
        for field in ("quantity", "average_price"):
            value = asset.get(field)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"{ticker}: {field} deve ser um número finito não negativo.")
    if not isinstance(config.get("fictitious"), bool):
        raise ValueError("Informe fictitious como true ou false.")
    return config
