"""Public snapshot exported from the single local SQLite database."""
import argparse
from contextlib import closing
import json
import os
import sqlite3
import tempfile
from pathlib import Path
from .portfolio import DEFAULT_DB, ROOT
from .market import utc_now


def snapshot(db):
    db.row_factory = sqlite3.Row
    result = {"schema_version": 1, "generated_at": utc_now(), "assets": []}
    for row in db.execute("SELECT * FROM portfolio_summary ORDER BY ticker").fetchall():
        asset = dict(row)
        ticker = asset["ticker"]
        quote = db.execute("SELECT * FROM latest_quotes WHERE ticker=?", (ticker,)).fetchone()
        asset["quote"] = dict(quote) if quote else None
        asset["history"] = [dict(r) for r in db.execute(
            "SELECT market_time,open,high,low,close,adjusted_close,volume FROM daily_prices WHERE ticker=? ORDER BY market_time", (ticker,))]
        asset["news"] = []
        for n in db.execute("""SELECT n.id,n.title,n.url,n.source_name,n.published_at,n.collected_at,
                n.summary,n.analysis_json,a.score FROM news n JOIN news_assets a ON a.news_id=n.id
                WHERE a.ticker=? ORDER BY julianday(n.published_at) DESC,n.id DESC LIMIT 10""", (ticker,)):
            item = dict(n)
            item["analysis"] = json.loads(item.pop("analysis_json")) if n["analysis_json"] else None
            asset["news"].append(item)
        asset["analysis_error"] = False
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='ai_status'").fetchone():
            status = db.execute("SELECT failed FROM ai_status WHERE ticker=?", (ticker,)).fetchone()
            asset["analysis_error"] = bool(status and status[0])
        asset["analysis"] = None
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='ai_analyses'").fetchone():
            from .analysis import input_for, input_hash
            fingerprint = input_hash(input_for(db, ticker))
            analysis = db.execute("SELECT result_json,generated_at,input_hash FROM ai_analyses WHERE ticker=? ORDER BY (input_hash=?) DESC,id DESC LIMIT 1", (ticker, fingerprint)).fetchone()
            if analysis:
                asset["analysis"] = {"result": json.loads(analysis["result_json"]),
                    "generated_at": analysis["generated_at"],
                    "stale": analysis["input_hash"] != fingerprint}
        result["assets"].append(asset)
    return result


def atomic_write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def export(db_path=DEFAULT_DB, output=ROOT.parent / "assets"):
    with closing(sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True)) as db:
        data = snapshot(db)
    text = json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2)
    atomic_write(Path(output) / "carteira.json", text)
    # Enables double-click preview without requiring a local web server.
    atomic_write(Path(output) / "carteira-data.js", "window.PORTFOLIO_DATA = " + text.replace("<", "\\u003c") + ";\n")
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default=str(DEFAULT_DB))
    parser.add_argument("--output", default=str(ROOT.parent / "assets"))
    args = parser.parse_args(argv)
    try:
        data = export(args.db, args.output)
        print(f"Dashboard exportada: {len(data['assets'])} ativos em {args.output}")
        return 0
    except (OSError, ValueError, sqlite3.Error) as exc:
        print(f"Falha na exportação: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
