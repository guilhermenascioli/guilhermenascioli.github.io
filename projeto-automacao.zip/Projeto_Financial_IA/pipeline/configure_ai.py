"""Interactive local Gemini key setup; never prints the key."""
import getpass
import json
from .portfolio import ROOT
from .dashboard import atomic_write


def main():
    print("Crie uma chave no Google AI Studio: https://aistudio.google.com/apikey")
    print("Use um projeto na faixa gratuita, sem faturamento habilitado.")
    print("O programa não consegue verificar o plano do projeto Google.")
    key = getpass.getpass("Cole a chave Gemini (entrada oculta): ").strip()
    if not key:
        print("Nenhuma alteração realizada.")
        return 1
    atomic_write(ROOT / "config" / "ia.local.json", json.dumps({"api_key": key, "model": "gemini-3.5-flash-lite"}))
    print("Chave salva localmente. Execute atualizar_carteira.bat para gerar as análises.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
